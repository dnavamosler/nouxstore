<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Aprendiendo PHP</title>
    <link href="https://fonts.googleapis.com/css?family=Proza+Libre" rel="stylesheet">

    <link rel="stylesheet" href="css/estilos.css" media="screen" title="no title">
  </head>
  <body>

    <div class="contenedor">
      <h1>Aprendiendo PHP</h1>

        <div class="contenido">

              <?php
$pagina = file_get_contents("http://www.ps3maracaibo.com/digitalcat.php");

 
 $fichero = 'prueba.html';
 file_put_contents($fichero,$pagina);
 
 
	$dom = new DOMDocument;
	$dom->loadXML(pagina);
	$books = $dom->getElementsByTagName('book');
foreach ($books as $book) {
    echo $book->nodeValue, PHP_EOL;
}
?>

	        </div>
    </div>



	<script src="js/jquery.js"></script>
	<script src="js/scripts.js></script>
  </body>
</html>
