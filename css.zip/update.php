<?php
					
	require 'dom/simple_html_dom.php';
		
		$ch = curl_init("http://www.ps3maracaibo.com/digitalcat.php");
		$fp = fopen("juegos.html", "w");

		curl_setopt($ch, CURLOPT_FILE, $fp);
		curl_setopt($ch, CURLOPT_HEADER, 0);

		$output = curl_exec($ch);
		curl_close($ch);
		fclose($fp);
	
	
	
	
	

	$html= new simple_html_dom();
	$html->load_file('juegos.html');
					
	$posts = $html->find('div[class=product-content]');
	$i=0;
	foreach( $posts as $post){
						
	$id=0;
						
	$resultado = 0;
	$texto =$post->find('h3',0)->plaintext;
	$texto = trim($texto);
	$precios = $html->find('p[class=centro]',$i);
	$i=$i+2;
	$cambio = $precios->__tostring();
	$resultado = intval(preg_replace('/[^0-9]+/', '', $cambio), 10);

	$resultado = (round((($resultado / 0.14) + 2000)/100.0,0)*100);
						
	if ($resultado != 0){
						
		$mysqli = new mysqli('localhost', 'pruebaco_nxs', 'MM19itpfe96!', 'pruebaco_nxs');
		$mysqli->set_charset("utf8mb4");
		$res = $mysqli->query("SELECT * FROM NXS_posts");
					
		while($f = $res->fetch_object()){
			$res2= $mysqli->query("SELECT * FROM NXS_postmeta");
			if(trim($f->post_title) == $texto){
			$id = $f->ID;
				while($cod_id = $res2->fetch_object()){
					if(($cod_id->post_id == $id) &&($cod_id->meta_key == '_price')){
						$llave_id = $cod_id->meta_id;
						$res3 = $mysqli->query("UPDATE `NXS_postmeta` SET `meta_value` = $resultado WHERE `NXS_postmeta`.`meta_id` = $llave_id");						
											 									
													}
															
									}
							}
												
						}
					$mysqli->close();
					
					}}
					
				?>