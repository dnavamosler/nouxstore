<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>NOUXSTORE</title>
    <link href="https://fonts.googleapis.com/css?family=Proza+Libre" rel="stylesheet">

    <link rel="stylesheet" href="css/estilos.css" media="screen" title="no title">
     <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,600,700,900|Raleway:300,400,500,700,900" rel="stylesheet">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  </head>
  <body>

    <div class="contenedor">
      <h1>NOUX<span>STORE</span></h1>
      
      <h2>Para Pedidos +56972019949 <i class="fab fa-whatsapp"></i></h2>

        <div class="contenido">

				<?php
					
	require 'dom/simple_html_dom.php';
		
		$ch = curl_init("http://www.ps3maracaibo.com/digitalcat.php");
		$fp = fopen("juegos.html", "w");

		curl_setopt($ch, CURLOPT_FILE, $fp);
		curl_setopt($ch, CURLOPT_HEADER, 0);

		$output = curl_exec($ch);
		curl_close($ch);
		fclose($fp);
	
	
	
	
	

	$html= new simple_html_dom();
	$html->load_file('juegos.html');
					
	$posts = $html->find('div[class=product-content]');
	$i=0;
	foreach( $posts as $post){
						
	$id=0;
						
	$resultado = 0;
	$texto =$post->find('h3',0)->plaintext;
	$texto = trim($texto);
	$precios = $html->find('p[class=centro]',$i);
	$i=$i+2;
	$cambio = $precios->__tostring();
	$resultado = intval(preg_replace('/[^0-9]+/', '', $cambio), 10);
		if($resultado != 0){

			$resultado = (round((($resultado / 0.180) + 2500)/100.0,0)*100);
			if($texto == 'FIFA 19 (PS3)')
				echo $texto .  ' - $' . 15000 . '<br>';
				else
			echo $texto .  ' - $' . $resultado . '<br>';
		}else{

			echo $texto .  ' - ' . 'no disponible' . '<br>';
		}
	
				
						
	/*if ($resultado != 0){
						
		$mysqli = new mysqli('localhost', 'pruebaco_nxs', 'MM19itpfe96!', 'pruebaco_nxs');
		$mysqli->set_charset("utf8mb4");
		$res = $mysqli->query("SELECT * FROM NXS_posts");
					
		while($f = $res->fetch_object()){
			$res2= $mysqli->query("SELECT * FROM NXS_postmeta");
			if(trim($f->post_title) == $texto){
			$id = $f->ID;
				while($cod_id = $res2->fetch_object()){
					if(($cod_id->post_id == $id) &&($cod_id->meta_key == '_price')){
						$llave_id = $cod_id->meta_id;
						$res3 = $mysqli->query("UPDATE `NXS_postmeta` SET `meta_value` = $resultado WHERE `NXS_postmeta`.`meta_id` = $llave_id");						
											 									
													}
															
									}
							}*/
												
						}
					//$mysqli->close();
					
					
					
				?>

	        </div>
    </div>



	<script src="js/jquery.js"></script>
	<script src="js/script.js></script>
  </body>
</html>
